/* --------------------------------o---x---o--------------------------------
 *          lista.h     declaración y primitivas del TDA LISTA
 *                      implementada en lista dinámica simplemente enlazada
 * --------------------------------o---x---o-------------------------------- */

#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#include <stdlib.h>
#include <string.h>


#define SIN_MEM         1
#define CLA_DUP         2
#define TODO_BIEN       0


typedef struct sNodo
{
    void           *info;
    unsigned        tamInfo;
    struct sNodo   *sig;
} tNodo;
typedef tNodo *tLista;


void crearLista(tLista *p);

int  listaVacia(const tLista *p);

int  listaLlena(const tLista *p, unsigned cantBytes);

void vaciarLista(tLista *p);

int  ponerAlComienzo(tLista *p, const void *d, unsigned cantBytes);

int  sacarPrimeroLista(tLista *p, void *d, unsigned cantBytes);

int  verPrimeroLista(const tLista *p, void *d, unsigned cantBytes);

int  ponerAlFinal(tLista *p, const void *d, unsigned cantBytes);

int  sacarUltimoLista(tLista *p, void *d, unsigned cantBytes);

int  verUltimoLista(const tLista *p, void *d, unsigned cantBytes);

void recorrerLista(const tLista *p,
                   unsigned cantBytes,
                   void (*mostrar)(const void *));

int insertarEnOrden(tLista *p,
                    const void *d,
                    unsigned cantBytes,
                    int (*comparar)(const void *, const void *),
                    void (*acumular)(void **, unsigned *,const void *, unsigned));


#endif // LISTA_H_INCLUDED
